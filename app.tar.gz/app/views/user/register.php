        <form method="POST">
            <input type="text" name="username" placeholder="username" />
            <input type="password" name="password" placeholder="password"/>
            <input type="text" name="email" placeholder="email" />
            <input type="submit" name="create" value="Create" />
        </form>