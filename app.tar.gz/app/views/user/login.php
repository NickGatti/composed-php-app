            <form method="POST">
                <input type="text" name="username" placeholder="Your Username" />
                <input type="password" name="password" placeholder="Your Password" />
                <input type="submit" name="submit" />
            </form>