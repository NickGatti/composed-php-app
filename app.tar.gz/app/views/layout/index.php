        <div>
            <h1>Welcome <?php echo $user->name ?></h1>
<?php $this->showContent(); ?>
        </div>