        <div>
            <h1><?php echo $header; ?></h1>
<?php $this->showContent(); ?>
            <p><a href="<?php echo $link; ?>"><?php echo $linkText; ?></a></p>
        </div>