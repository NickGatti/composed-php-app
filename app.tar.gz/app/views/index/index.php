            <p>You are logged in!</p>
            <p><a href="/user/logout">Log Out</a></p>