<?php

class SQLiteUser extends BasicUser {
    
    const DATA_DIR = __DIR__ . '/../data/users.db';
    
    protected function getUsers() {
        $database = new SQLite3(self::DATA_DIR);
        $userQuery = $database->query(
            'SELECT * FROM users JOIN details ON users.detail_id = details.id'
        );
        $result = [];
        
        while($userRow = $userQuery->fetchArray(SQLITE3_ASSOC)) {
            $result[$userRow['username']] = $userRow;
        }
        
        $database->close();
        return $result;
    }
    
    public static function create(string $username, string $password, array $optional = []) {
        $database = new SQLite3(self::DATA_DIR);
        
        $addDetail = $database->prepare('INSERT INTO details (email) VALUES (:email)');
        $addUser = $database->prepare('INSERT INTO users (username, password, detail_id) VALUES (:un, :pw, :did)');
        
        $addDetail->bindValue(':email', $optional['email'] ?: '', SQLITE3_TEXT);
        $addDetail->execute();
        
        $addUser->bindValue(':un', $database->escapeString(htmlentities($username)), SQLITE3_TEXT);
        $addUser->bindValue(':pw', md5($password), SQLITE3_TEXT);
        $addUser->bindValue(':did', $database->lastInsertRowID(), SQLITE3_INTEGER);
        $addUser->execute();
        
        $database->close();
    }
    
}
